var searchData=
[
  ['peripherals_924',['Peripherals',['../group__PERIPHERALS.html',1,'']]],
  ['peripherals_20public_20functions_925',['Peripherals Public Functions',['../group__Peripherals__Public__Functions.html',1,'']]]
];
