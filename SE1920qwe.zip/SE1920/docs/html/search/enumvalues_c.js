var searchData=
[
  ['prepare_5ffor_5fwrite_833',['PREPARE_FOR_WRITE',['../group__IAP__Public__ENUMS.html#gga4196c28170e166a21fa7a7f1e416ec1ba1bf8ecfa46624cc0aa74104111c4b480',1,'IAP.h']]]
];
