var searchData=
[
  ['max_5fdays_5fin_5fmonth_740',['MAX_DAYS_IN_MONTH',['../group__Data__Storage__Public__Constants.html#ga3db66d211b1e578c5692c0d161a2dbfa',1,'data_storage.h']]],
  ['month_741',['MONTH',['../group__Data__Storage__Public__Constants.html#ga55861a7e9de0d3e935c8e767408122bd',1,'data_storage.h']]]
];
