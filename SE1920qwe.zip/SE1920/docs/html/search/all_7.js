var searchData=
[
  ['get_5fchip_5fid_208',['get_chip_ID',['../group__BMP280__Public__FUNCTIONS.html#gaccb2730c3115a1f011cbed7535e11bda',1,'get_chip_ID():&#160;BMP280.c'],['../group__BMP280__Public__FUNCTIONS.html#gaccb2730c3115a1f011cbed7535e11bda',1,'get_chip_ID():&#160;BMP280.c']]],
  ['get_5fcurrentfield_209',['get_CurrentField',['../group__Data__Storage__Public__Functions.html#ga62aca0e9e94638cd44405f132494d867',1,'get_CurrentField():&#160;data_storage.c'],['../group__Data__Storage__Public__Functions.html#ga62aca0e9e94638cd44405f132494d867',1,'get_CurrentField():&#160;data_storage.c']]],
  ['get_5fdate_210',['get_Date',['../group__Data__Storage__Public__Functions.html#gadd2a0539823aa5aad709c7d35d24a15f',1,'get_Date(char *str):&#160;data_storage.c'],['../group__Data__Storage__Public__Functions.html#gadd2a0539823aa5aad709c7d35d24a15f',1,'get_Date(char *str):&#160;data_storage.c']]],
  ['get_5ftemperature_211',['get_Temperature',['../group__Data__Storage__Public__Functions.html#ga305a4b36166fd5d22ead3f5e502e8683',1,'get_Temperature(char *str):&#160;data_storage.c'],['../group__Data__Storage__Public__Functions.html#ga305a4b36166fd5d22ead3f5e502e8683',1,'get_Temperature(char *str):&#160;data_storage.c']]],
  ['get_5ftime_212',['get_Time',['../group__Data__Storage__Public__Functions.html#gafe5910caec14ed0fda08121de019bb11',1,'get_Time(char *str):&#160;data_storage.c'],['../group__Data__Storage__Public__Functions.html#gafe5910caec14ed0fda08121de019bb11',1,'get_Time(char *str):&#160;data_storage.c']]],
  ['gmt_5fplus_5fone_213',['GMT_PLUS_ONE',['../group__RTC__Public__DATE__ADJUSTMENTS.html#gad361d4bd9333fe9856d9b9d846e1da2a',1,'rtc.h']]]
];
