var searchData=
[
  ['year_5fmask_865',['YEAR_MASK',['../group__RTC__Public__ENUMS.html#ggaaafe91e8779320607f65af4b63848a4aa0546064b40065c571208a4de4ebda7b4',1,'rtc.h']]]
];
