var searchData=
[
  ['year_5fbits_652',['YEAR_BITS',['../rtc_8h.html#a4e89ee91c022b8492a34093d4067a069',1,'rtc.h']]],
  ['year_5fposition_653',['YEAR_POSITION',['../rtc_8h.html#adad6eb5bbe06428120311e163b70a55a',1,'rtc.h']]]
];
