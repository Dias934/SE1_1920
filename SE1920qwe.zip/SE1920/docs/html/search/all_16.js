var searchData=
[
  ['year_5fbits_552',['YEAR_BITS',['../group__RTC__Public__DATE__VARIABLES__BITS__POSITION.html#ga4e89ee91c022b8492a34093d4067a069',1,'rtc.h']]],
  ['year_5fmask_553',['YEAR_MASK',['../group__RTC__Public__ENUMS.html#ggaaafe91e8779320607f65af4b63848a4aa0546064b40065c571208a4de4ebda7b4',1,'rtc.h']]],
  ['year_5foffset_554',['YEAR_OFFSET',['../group__Data__Storage__Public__Constants.html#gacee36213e4ac3985f3299182229fc7ba',1,'data_storage.h']]],
  ['year_5fposition_555',['YEAR_POSITION',['../group__RTC__Public__DATE__VARIABLES__BITS__POSITION.html#gadad6eb5bbe06428120311e163b70a55a',1,'rtc.h']]]
];
