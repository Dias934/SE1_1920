var searchData=
[
  ['c_5fval_731',['C_VAL',['../group__HD44780__Display__Control__Command.html#gaca0262a9f45dc091ab4fc6cdad5fdeb0',1,'HD44780.h']]],
  ['cpha_5fcpol_5fvalues_732',['CPHA_CPOL_VALUES',['../group__SPI__Control__Register.html#gaf4106900a50ebd346520edb989597de9',1,'SPI.h']]]
];
