var searchData=
[
  ['sec_5fbits_645',['SEC_BITS',['../rtc_8h.html#abde6be2e893748e5be41abb9c047e242',1,'rtc.h']]],
  ['sec_5fposition_646',['SEC_POSITION',['../rtc_8h.html#ab7c865e6d32344d499bd843b77ef25d7',1,'rtc.h']]],
  ['spi_5ffunction_647',['SPI_FUNCTION',['../SPI_8h.html#a621b56e8c09a1741b00110484a61a65b',1,'SPI.h']]],
  ['spif_648',['SPIF',['../SPI_8h.html#ac345ddc9e794f439292ab0019d53c226',1,'SPI.h']]]
];
