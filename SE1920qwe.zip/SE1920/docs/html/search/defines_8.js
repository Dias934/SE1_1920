var searchData=
[
  ['spi_5ffunction_644',['SPI_FUNCTION',['../SPI_8h.html#a621b56e8c09a1741b00110484a61a65b',1,'SPI.h']]],
  ['spif_645',['SPIF',['../SPI_8h.html#ac345ddc9e794f439292ab0019d53c226',1,'SPI.h']]]
];
