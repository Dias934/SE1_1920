var searchData=
[
  ['s_5fc_5fval_748',['S_C_VAL',['../group__HD44780__Cursor__Display__Shift__Command.html#ga97a5457ebcce77c58de56c5af17b2b19',1,'HD44780.h']]],
  ['s_5fval_749',['S_VAL',['../group__HD44780__Entry__Mode__Set__Command.html#ga0f3530cba19e1599ee8d3c9a84c1dc57',1,'HD44780.h']]],
  ['spi3w_5fen_5fval_750',['SPI3W_EN_VAL',['../group__BMP280__Public__ENUMS.html#gab6e513eed16e37b04360c684aac6a902',1,'BMP280.h']]]
];
