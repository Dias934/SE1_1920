var searchData=
[
  ['set_20cgram_20address_20command_938',['Set CGRAM Address Command',['../group__HD44780__Set__CGRAM__ADDR__Command.html',1,'']]],
  ['set_20ddram_20address_20command_939',['Set DDRAM Address Command',['../group__HD44780__Set__DDRAM__ADDR__Command.html',1,'']]],
  ['spi_940',['SPI',['../group__SPI.html',1,'']]],
  ['spi_20control_20register_941',['SPI Control Register',['../group__SPI__Control__Register.html',1,'']]],
  ['spi_20public_20constants_942',['SPI Public Constants',['../group__SPI__Public__Constants.html',1,'']]],
  ['spi_20public_20functions_943',['SPI Public Functions',['../group__SPI__Public__Functions.html',1,'']]],
  ['spi_20status_20register_944',['SPI Status Register',['../group__SPI__Status__Register.html',1,'']]]
];
