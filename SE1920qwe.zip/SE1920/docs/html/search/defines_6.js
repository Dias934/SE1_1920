var searchData=
[
  ['pclk_5fcclk_5ffunction_5fl_638',['PCLK_CCLK_FUNCTION_L',['../SPI_8h.html#af0e17ae9f64a761f0b8fcd5ff685c0aa',1,'SPI.h']]],
  ['pclk_5fspi_5fbit_5fposition_639',['PCLK_SPI_BIT_POSITION',['../SPI_8h.html#a27c3598eb1cc76bff82df07947584dba',1,'SPI.h']]],
  ['pinsel_5fmiso_5fbit_5fpos_640',['PINSEL_MISO_BIT_POS',['../SPI_8h.html#abede6e74bc60aa2fd6a37e866b160bf3',1,'SPI.h']]],
  ['pinsel_5fmosi_5fbit_5fpos_641',['PINSEL_MOSI_BIT_POS',['../SPI_8h.html#a6baa5b6d75a47845cd6028e704b24a97',1,'SPI.h']]],
  ['pinsel_5fsck_5fbit_5fpos_642',['PINSEL_SCK_BIT_POS',['../SPI_8h.html#a65fe549011677c5b557b20349dc6c2ac',1,'SPI.h']]]
];
