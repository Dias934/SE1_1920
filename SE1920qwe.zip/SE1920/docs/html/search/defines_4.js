var searchData=
[
  ['two_5fseconds_862',['TWO_SECONDS',['../menu_8h.html#aa1ed18b4bb5bac671a272e0247d4d817',1,'menu.h']]]
];
