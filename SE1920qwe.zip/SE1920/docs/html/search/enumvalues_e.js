var searchData=
[
  ['sec_5fmask_838',['SEC_MASK',['../group__RTC__Public__ENUMS.html#ggaaafe91e8779320607f65af4b63848a4aadb5adb83aa57876d08051ab5634ad490',1,'rtc.h']]],
  ['sector_5fnot_5fblank_839',['SECTOR_NOT_BLANK',['../group__IAP__Public__ENUMS.html#gga4d48a0fd200dee5bb5aa763e07bec243ab1f63a703766fecd25893860833489b8',1,'IAP.h']]],
  ['sector_5fnot_5fprepared_5ffor_5fwrite_5foperation_840',['SECTOR_NOT_PREPARED_FOR_WRITE_OPERATION',['../group__IAP__Public__ENUMS.html#gga4d48a0fd200dee5bb5aa763e07bec243a452c999bb4501c15d9e9f92f605bc8a4',1,'IAP.h']]],
  ['september_841',['SEPTEMBER',['../group__Data__Storage__Public__Constants.html#gga55861a7e9de0d3e935c8e767408122bdad3da1ebcdb93dbc04b8cd63b7e1bc84b',1,'data_storage.h']]],
  ['september_5fdays_842',['SEPTEMBER_DAYS',['../group__Data__Storage__Public__Constants.html#gga3db66d211b1e578c5692c0d161a2dbfaa32bf2e4bf0fb6e08f6460ac21a34494b',1,'data_storage.h']]],
  ['shift_5fdisable_843',['SHIFT_DISABLE',['../group__HD44780__Entry__Mode__Set__Command.html#gga0f3530cba19e1599ee8d3c9a84c1dc57ada9d3256c472c9abf93829e842e4d27f',1,'HD44780.h']]],
  ['shift_5fenable_844',['SHIFT_ENABLE',['../group__HD44780__Entry__Mode__Set__Command.html#gga0f3530cba19e1599ee8d3c9a84c1dc57a49335507e66818bed6669e62a5945dcb',1,'HD44780.h']]],
  ['shift_5fleft_845',['SHIFT_LEFT',['../group__HD44780__Cursor__Display__Shift__Command.html#gga7c5d839d7aa0510d387d3e1777cbadf1a6b92a832eae42ec7818fa36a5c5b4799',1,'HD44780.h']]],
  ['shift_5fright_846',['SHIFT_RIGHT',['../group__HD44780__Cursor__Display__Shift__Command.html#gga7c5d839d7aa0510d387d3e1777cbadf1aac747046082df3e61fbd91b181a92a1c',1,'HD44780.h']]],
  ['sixteen_5fbits_847',['SIXTEEN_BITS',['../group__SPI__Control__Register.html#ggaf84fb91f73047dadd657ae4d87cdbc3fa98362d60d3e99e44f3c9d8466d988007',1,'SPI.h']]],
  ['skipped_848',['SKIPPED',['../group__BMP280__Public__ENUMS.html#ggab248c57cf757c5ce35fee5d0a5deec83a7b3e3be20ffe941881dfab27e5f6fd7e',1,'BMP280.h']]],
  ['sleep_5fmode_849',['SLEEP_MODE',['../group__BMP280__Public__ENUMS.html#gga250049916a5f2cd49f5d32212a724fc2ad1486bda2c3e55fd939260a6b7e38020',1,'BMP280.h']]],
  ['spi_850',['SPI',['../group__BMP280__Public__ENUMS.html#ggab6e513eed16e37b04360c684aac6a902aefea9eb0772378037221a3f1fe759a76',1,'BMP280.h']]],
  ['src_5faddr_5ferror_851',['SRC_ADDR_ERROR',['../group__IAP__Public__ENUMS.html#gga4d48a0fd200dee5bb5aa763e07bec243ae8e1700ae64fd2768bffba7021b7d952',1,'IAP.h']]],
  ['src_5faddr_5fnot_5fmapped_852',['SRC_ADDR_NOT_MAPPED',['../group__IAP__Public__ENUMS.html#gga4d48a0fd200dee5bb5aa763e07bec243abac1183d3d8b9b697797e6bd7f332c45',1,'IAP.h']]]
];
