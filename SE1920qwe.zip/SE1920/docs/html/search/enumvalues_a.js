var searchData=
[
  ['nine_5fbits_821',['NINE_BITS',['../group__SPI__Control__Register.html#ggaf84fb91f73047dadd657ae4d87cdbc3fa7f56679ba4741f1494665c19a0529c3a',1,'SPI.h']]],
  ['normal_5fmode_822',['NORMAL_MODE',['../group__BMP280__Public__ENUMS.html#gga250049916a5f2cd49f5d32212a724fc2a83feb61d42f8db9f494019fcea2c0148',1,'BMP280.h']]],
  ['november_823',['NOVEMBER',['../group__Data__Storage__Public__Constants.html#gga55861a7e9de0d3e935c8e767408122bda3356ccc34e34421d48e6c4b1e68515fe',1,'data_storage.h']]],
  ['november_5fdays_824',['NOVEMBER_DAYS',['../group__Data__Storage__Public__Constants.html#gga3db66d211b1e578c5692c0d161a2dbfaaf4993a63732bb19ab85cbdaebe1b67f0',1,'data_storage.h']]]
];
