/*
@licstart  The following is the entire license notice for the
JavaScript code in this file.

Copyright (C) 1997-2019 by Dimitri van Heesch

This program is free software; you can redistribute it and/or modify
it under the terms of version 2 of the GNU General Public License as published by
the Free Software Foundation

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

@licend  The above is the entire license notice
for the JavaScript code in this file
*/
var menudata={children:[
{text:"Main Page",url:"index.html"},
{text:"Modules",url:"modules.html"},
{text:"Files",url:"files.html",children:[
{text:"File List",url:"files.html"},
{text:"Globals",url:"globals.html",children:[
{text:"All",url:"globals.html",children:[
{text:"_",url:"globals.html#index__5F"},
{text:"a",url:"globals.html#index_a"},
{text:"b",url:"globals.html#index_b"},
{text:"c",url:"globals.html#index_c"},
{text:"d",url:"globals.html#index_d"},
{text:"e",url:"globals.html#index_e"},
{text:"f",url:"globals.html#index_f"},
{text:"g",url:"globals.html#index_g"},
{text:"h",url:"globals.html#index_h"},
{text:"i",url:"globals.html#index_i"},
{text:"j",url:"globals.html#index_j"},
{text:"m",url:"globals.html#index_m"},
{text:"n",url:"globals.html#index_n"},
{text:"o",url:"globals.html#index_o"},
{text:"p",url:"globals.html#index_p"},
{text:"r",url:"globals.html#index_r"},
{text:"s",url:"globals.html#index_s"},
{text:"t",url:"globals.html#index_t"},
{text:"u",url:"globals.html#index_u"},
{text:"v",url:"globals.html#index_v"},
{text:"w",url:"globals.html#index_w"},
{text:"y",url:"globals.html#index_y"}]},
{text:"Functions",url:"globals_func.html",children:[
{text:"_",url:"globals_func.html#index__5F"},
{text:"b",url:"globals_func.html#index_b"},
{text:"c",url:"globals_func.html#index_c"},
{text:"d",url:"globals_func.html#index_d"},
{text:"g",url:"globals_func.html#index_g"},
{text:"h",url:"globals_func.html#index_h"},
{text:"i",url:"globals_func.html#index_i"},
{text:"m",url:"globals_func.html#index_m"},
{text:"n",url:"globals_func.html#index_n"},
{text:"p",url:"globals_func.html#index_p"},
{text:"r",url:"globals_func.html#index_r"},
{text:"s",url:"globals_func.html#index_s"},
{text:"t",url:"globals_func.html#index_t"},
{text:"u",url:"globals_func.html#index_u"},
{text:"v",url:"globals_func.html#index_v"},
{text:"w",url:"globals_func.html#index_w"}]},
{text:"Variables",url:"globals_vars.html",children:[
{text:"_",url:"globals_vars.html#index__5F"},
{text:"a",url:"globals_vars.html#index_a"},
{text:"b",url:"globals_vars.html#index_b"},
{text:"c",url:"globals_vars.html#index_c"},
{text:"d",url:"globals_vars.html#index_d"},
{text:"e",url:"globals_vars.html#index_e"},
{text:"f",url:"globals_vars.html#index_f"},
{text:"m",url:"globals_vars.html#index_m"},
{text:"s",url:"globals_vars.html#index_s"},
{text:"t",url:"globals_vars.html#index_t"},
{text:"u",url:"globals_vars.html#index_u"},
{text:"v",url:"globals_vars.html#index_v"}]},
{text:"Enumerations",url:"globals_enum.html"},
{text:"Enumerator",url:"globals_eval.html"},
{text:"Macros",url:"globals_defs.html"}]}]}]}
