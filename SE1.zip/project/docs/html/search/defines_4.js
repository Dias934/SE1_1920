var searchData=
[
  ['pressing_5ftime_232',['PRESSING_TIME',['../menu_8h.html#aaea57e2b5d2fcc24b20f8947721732f7',1,'menu.h']]]
];
