var searchData=
[
  ['month_5foffset_230',['MONTH_OFFSET',['../data__storage_8h.html#a9ec8a432e73cdaf875b06f6bdb42bd77',1,'data_storage.h']]]
];
