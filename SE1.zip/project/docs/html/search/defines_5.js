var searchData=
[
  ['release_5ftime_233',['RELEASE_TIME',['../menu_8h.html#a3bce5283c2355dce35e7cd4305b20116',1,'menu.h']]]
];
