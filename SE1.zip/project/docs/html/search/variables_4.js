var searchData=
[
  ['date_5foffsets_236',['DATE_OFFSETS',['../group__DATA__STORAGE__STATIC__CONSTANTS.html#ga6c6fa9e2d2e40264e751c00abb30c9e4',1,'data_storage.c']]],
  ['date_5fptrs_237',['DATE_PTRS',['../group__DATA__STORAGE__STATIC__CONSTANTS.html#ga90b0fb72e6449293d849ddfd2745cad2',1,'data_storage.c']]],
  ['datetime_238',['dateTime',['../data__storage_8c.html#a538756e7376d93ef852984d47ea29cbb',1,'data_storage.c']]]
];
