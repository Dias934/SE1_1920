var searchData=
[
  ['december_264',['DECEMBER',['../group__Data__Storage__Public__Constants.html#gga55861a7e9de0d3e935c8e767408122bda823acaf8f57efe16924d4233a9547c03',1,'data_storage.h']]],
  ['december_5fdays_265',['DECEMBER_DAYS',['../group__Data__Storage__Public__Constants.html#gga3db66d211b1e578c5692c0d161a2dbfaae1110f7e086058c36def47c2a4a7c0ab',1,'data_storage.h']]]
];
