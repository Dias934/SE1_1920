var searchData=
[
  ['aux_230',['aux',['../group__DATA__STORAGE__STATIC__VARIABLES.html#ga2f27998c9597f8f04230569da45688ba',1,'data_storage.c']]]
];
