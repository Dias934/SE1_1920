var searchData=
[
  ['year_5foffset_239',['YEAR_OFFSET',['../data__storage_8h.html#acee36213e4ac3985f3299182229fc7ba',1,'data_storage.h']]]
];
