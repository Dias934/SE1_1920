var searchData=
[
  ['celsius_174',['celsius',['../group__DATA__STORAGE__STATIC__FUNCTIONS.html#ga96e9df8b784eae4bbca67dcffe933d22',1,'data_storage.c']]],
  ['celsius_5fto_5ffahrenheit_175',['celsius_to_fahrenheit',['../group__DATA__STORAGE__STATIC__FUNCTIONS.html#gacfa302c87bc4af7761589fb1228716d6',1,'data_storage.c']]],
  ['change_5fdate_176',['change_date',['../group__Data__Storage__Public__Functions.html#gad94da7a78041e3e1629862d997887922',1,'change_date(int val):&#160;data_storage.c'],['../group__Data__Storage__Public__Functions.html#gad94da7a78041e3e1629862d997887922',1,'change_date(int val):&#160;data_storage.c']]],
  ['change_5ftemp_5funit_177',['change_temp_unit',['../group__Data__Storage__Public__Functions.html#gad50d7b09bea4f9ba2cb7e0580cf4efc3',1,'change_temp_unit(int val):&#160;data_storage.c'],['../group__Data__Storage__Public__Functions.html#gad50d7b09bea4f9ba2cb7e0580cf4efc3',1,'change_temp_unit(int val):&#160;data_storage.c']]],
  ['change_5ftime_178',['change_time',['../group__Data__Storage__Public__Functions.html#gaf1bff18ea1b49edaff24fa805b4c0225',1,'change_time(int val):&#160;data_storage.c'],['../group__Data__Storage__Public__Functions.html#gaf1bff18ea1b49edaff24fa805b4c0225',1,'change_time(int val):&#160;data_storage.c']]]
];
