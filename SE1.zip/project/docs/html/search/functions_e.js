var searchData=
[
  ['view_5fchange_5fdate_220',['view_change_date',['../group__VIEW__Public__FUNCTIONS.html#ga3d879c86a85966c5e54d14e7fc264b7c',1,'view_change_date():&#160;view.c'],['../group__VIEW__Public__FUNCTIONS.html#ga3d879c86a85966c5e54d14e7fc264b7c',1,'view_change_date():&#160;view.c']]],
  ['view_5fchange_5ftemperature_5funits_221',['view_change_temperature_units',['../group__VIEW__Public__FUNCTIONS.html#ga3b883d3c130cc7884a211f36dc1b6318',1,'view_change_temperature_units():&#160;view.c'],['../group__VIEW__Public__FUNCTIONS.html#ga3b883d3c130cc7884a211f36dc1b6318',1,'view_change_temperature_units():&#160;view.c']]],
  ['view_5fchange_5ftime_222',['view_change_time',['../group__VIEW__Public__FUNCTIONS.html#ga1b05e078a764eb1639d394abbe7eb123',1,'view_change_time():&#160;view.c'],['../group__VIEW__Public__FUNCTIONS.html#ga1b05e078a764eb1639d394abbe7eb123',1,'view_change_time():&#160;view.c']]],
  ['view_5fmaintenance_223',['view_maintenance',['../group__VIEW__Public__FUNCTIONS.html#ga4f4e6a92b8929d61f3ae2c0984b203cf',1,'view_maintenance(short idx):&#160;view.c'],['../group__VIEW__Public__FUNCTIONS.html#ga4f4e6a92b8929d61f3ae2c0984b203cf',1,'view_maintenance(short idx):&#160;view.c']]],
  ['view_5fnormal_224',['view_normal',['../group__VIEW__Public__FUNCTIONS.html#gafacebc30938ba41cf08c0e252a1d29c5',1,'view_normal():&#160;view.c'],['../group__VIEW__Public__FUNCTIONS.html#gafacebc30938ba41cf08c0e252a1d29c5',1,'view_normal():&#160;view.c']]]
];
