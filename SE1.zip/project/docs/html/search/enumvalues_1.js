var searchData=
[
  ['celsius_263',['CELSIUS',['../group__Data__Storage__Public__Constants.html#ggae7dc56e01d88f26086565dce8c23dad6ab788c882d39407e80b48d2a10786eae7',1,'data_storage.h']]]
];
