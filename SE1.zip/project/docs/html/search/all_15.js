var searchData=
[
  ['year_5foffset_157',['YEAR_OFFSET',['../group__Data__Storage__Public__Constants.html#gacee36213e4ac3985f3299182229fc7ba',1,'data_storage.h']]]
];
