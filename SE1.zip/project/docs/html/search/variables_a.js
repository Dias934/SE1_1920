var searchData=
[
  ['unit_252',['unit',['../group__DATA__STORAGE__STATIC__VARIABLES.html#ga09cef70e6322053ea80ae603446346c5',1,'data_storage.c']]],
  ['up_5fdown_5ffunc_253',['up_down_func',['../menu__maintenance_8c.html#a06e23300caf8264a75c8a85e27348a87',1,'menu_maintenance.c']]]
];
