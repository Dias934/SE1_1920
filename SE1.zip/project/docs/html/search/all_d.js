var searchData=
[
  ['october_106',['OCTOBER',['../group__Data__Storage__Public__Constants.html#gga55861a7e9de0d3e935c8e767408122bda554aba97586ee43f0ca51b0089eed03c',1,'data_storage.h']]],
  ['october_5fdays_107',['OCTOBER_DAYS',['../group__Data__Storage__Public__Constants.html#gga3db66d211b1e578c5692c0d161a2dbfaa79833c3727b4d77470df5caf06bf0b4c',1,'data_storage.h']]],
  ['one_5fsecond_108',['ONE_SECOND',['../group__MENU__Public__Constants.html#gac93edbf7e8fdbf7398453d51bbd37a97',1,'menu.h']]]
];
