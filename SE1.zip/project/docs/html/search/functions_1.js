var searchData=
[
  ['backup_5fdatetime_172',['backup_dateTime',['../group__Data__Storage__Public__Functions.html#gaff0655a1a0c1ad7d11dd3a1b72b4a97e',1,'backup_dateTime():&#160;data_storage.c'],['../group__Data__Storage__Public__Functions.html#gaff0655a1a0c1ad7d11dd3a1b72b4a97e',1,'backup_dateTime():&#160;data_storage.c']]],
  ['busfault_5fhandler_173',['BusFault_Handler',['../cr__startup__lpc175x__6x_8c.html#ae216256baeae935e04745241645d44c0',1,'cr_startup_lpc175x_6x.c']]]
];
