var searchData=
[
  ['c_5fval_500',['C_VAL',['../group__HD44780__Display__Control__Command.html#gaca0262a9f45dc091ab4fc6cdad5fdeb0',1,'HD44780.h']]],
  ['cpha_5fcpol_5fvalues_501',['CPHA_CPOL_VALUES',['../spi_8h.html#af4106900a50ebd346520edb989597de9',1,'spi.h']]]
];
