var searchData=
[
  ['spi_5ffunction_629',['SPI_FUNCTION',['../spi_8h.html#a621b56e8c09a1741b00110484a61a65b',1,'spi.h']]],
  ['spif_630',['SPIF',['../spi_8h.html#ac345ddc9e794f439292ab0019d53c226',1,'spi.h']]]
];
