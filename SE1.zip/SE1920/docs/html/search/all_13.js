var searchData=
[
  ['year_5fbits_406',['YEAR_BITS',['../group__RTC__Public__DATE__VARIABLES__BITS__POSITION.html#ga4e89ee91c022b8492a34093d4067a069',1,'rtc.h']]],
  ['year_5fmask_407',['YEAR_MASK',['../group__RTC__Public__ENUMS.html#ggaaafe91e8779320607f65af4b63848a4aa0546064b40065c571208a4de4ebda7b4',1,'rtc.h']]],
  ['year_5fposition_408',['YEAR_POSITION',['../group__RTC__Public__DATE__VARIABLES__BITS__POSITION.html#gadad6eb5bbe06428120311e163b70a55a',1,'rtc.h']]]
];
