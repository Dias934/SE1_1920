var searchData=
[
  ['lsbf_5fbit_5fposition_618',['LSBF_BIT_POSITION',['../spi_8h.html#a2c50cdd6714e776818d84c842abcc9c8',1,'spi.h']]]
];
