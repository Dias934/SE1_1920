var searchData=
[
  ['get_5fchip_5fid_161',['get_chip_ID',['../group__BMP280__Public__FUNCTIONS.html#gaccb2730c3115a1f011cbed7535e11bda',1,'get_chip_ID():&#160;BMP280.c'],['../group__BMP280__Public__FUNCTIONS.html#gaccb2730c3115a1f011cbed7535e11bda',1,'get_chip_ID():&#160;BMP280.c']]],
  ['gmt_5fplus_5fone_162',['GMT_PLUS_ONE',['../group__RTC__Public__DATE__ADJUSTMENTS.html#gad361d4bd9333fe9856d9b9d846e1da2a',1,'rtc.h']]]
];
