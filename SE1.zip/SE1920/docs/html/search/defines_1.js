var searchData=
[
  ['bit_5fenable_5fbit_5fposition_608',['BIT_ENABLE_BIT_POSITION',['../spi_8h.html#a5ec424b868756c3cb81ae4291690ac5a',1,'spi.h']]],
  ['bits_5fbit_5fposition_609',['BITS_BIT_POSITION',['../spi_8h.html#a4ea4d13793cc274b1ce46601b018ccc8',1,'spi.h']]],
  ['bits_5fmask_610',['BITS_MASK',['../spi_8h.html#a2fe283bc1d320f1046d6c5a68fa491b8',1,'spi.h']]],
  ['bits_5fmode_611',['BITS_MODE',['../spi_8h.html#accf43c429fd43c706460bdc342738476',1,'spi.h']]]
];
