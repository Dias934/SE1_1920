var searchData=
[
  ['b_5fval_498',['B_VAL',['../group__HD44780__Display__Control__Command.html#gaa4e94453f2dc8c9a941996bf94de286f',1,'HD44780.h']]],
  ['bits_499',['BITS',['../spi_8h.html#af84fb91f73047dadd657ae4d87cdbc3f',1,'spi.h']]]
];
