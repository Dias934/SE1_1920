var searchData=
[
  ['master_5fmode_619',['MASTER_MODE',['../spi_8h.html#a475c4661b2c820f9cd1d1ed57b1b576f',1,'spi.h']]],
  ['master_5fmode_5fbit_5fposition_620',['MASTER_MODE_BIT_POSITION',['../spi_8h.html#abcb1c71d73c8b27e0c893270b8697f14',1,'spi.h']]],
  ['modf_621',['MODF',['../spi_8h.html#a022fefdb92bb304842c479d15cfa0847',1,'spi.h']]],
  ['msb_5fmode_5fl_622',['MSB_MODE_L',['../spi_8h.html#a3b3dd347b8fed86ebb054867ef619062',1,'spi.h']]]
];
