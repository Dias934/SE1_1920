var searchData=
[
  ['wcol_631',['WCOL',['../spi_8h.html#a32eb1801f1dddc0d4079ea5fa3c0934b',1,'spi.h']]]
];
