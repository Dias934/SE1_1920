var searchData=
[
  ['cpha_5fcpol_5fbit_5fmask_612',['CPHA_CPOL_BIT_MASK',['../spi_8h.html#a58915272d0a277f6589f617f721250fc',1,'spi.h']]],
  ['cpha_5fcpol_5fbit_5fposition_613',['CPHA_CPOL_BIT_POSITION',['../spi_8h.html#a54671b599eff1127d9c542ded8c86f86',1,'spi.h']]],
  ['custom_5fconfig_5ftransfer_614',['CUSTOM_CONFIG_TRANSFER',['../spi_8h.html#a62103811b1a829451075e377845141c7',1,'spi.h']]]
];
