var searchData=
[
  ['default_5fdatabit_615',['DEFAULT_DATABIT',['../spi_8h.html#ace91db2c7517d5d10334d703cf175be7',1,'spi.h']]],
  ['default_5ffrequency_616',['DEFAULT_FREQUENCY',['../spi_8h.html#a052b63090cda80236391c5fc0c1fe30c',1,'spi.h']]],
  ['default_5fmode_617',['DEFAULT_MODE',['../spi_8h.html#ab9c800875296f23bd616d7d273ff16d7',1,'spi.h']]]
];
