var searchData=
[
  ['nine_5fbits_567',['NINE_BITS',['../spi_8h.html#af84fb91f73047dadd657ae4d87cdbc3fa7f56679ba4741f1494665c19a0529c3a',1,'spi.h']]],
  ['normal_5fmode_568',['NORMAL_MODE',['../group__BMP280__Public__ENUMS.html#gga250049916a5f2cd49f5d32212a724fc2a83feb61d42f8db9f494019fcea2c0148',1,'BMP280.h']]]
];
