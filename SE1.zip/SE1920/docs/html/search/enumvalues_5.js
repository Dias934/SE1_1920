var searchData=
[
  ['hour_5fmask_560',['HOUR_MASK',['../group__RTC__Public__ENUMS.html#ggaaafe91e8779320607f65af4b63848a4aad22f14df9fcaf1aa8e2e7a0fd38a5cf0',1,'rtc.h']]]
];
