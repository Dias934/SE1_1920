var searchData=
[
  ['_5f_5fms_83',['__ms',['../group__WAIT__Public__Variables.html#ga2a22088ea3076d5b461780c0a7efcf07',1,'__ms():&#160;wait.c'],['../group__WAIT__Public__Variables.html#ga2a22088ea3076d5b461780c0a7efcf07',1,'__ms():&#160;wait.c']]]
];
