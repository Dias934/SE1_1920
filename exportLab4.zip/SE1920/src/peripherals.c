/*
 * peripherals.c
 *
 *  Created on: 22/10/2019
 *      Author: A38866
 */

#include "peripherals.h"

void init_peripherals(){
	init_wait();
	time_t rawtime;
	time(&rawtime);
	init_RTC(rawtime);
	init_ui();
}
