var searchData=
[
  ['s_5fc_5fval_224',['S_C_VAL',['../group__HD44780__Cursor__Display__Shift__Command.html#ga97a5457ebcce77c58de56c5af17b2b19',1,'HD44780.h']]],
  ['s_5fval_225',['S_VAL',['../group__HD44780__Entry__Mode__Set__Command.html#ga0f3530cba19e1599ee8d3c9a84c1dc57',1,'HD44780.h']]]
];
