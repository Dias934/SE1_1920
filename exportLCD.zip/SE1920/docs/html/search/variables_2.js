var searchData=
[
  ['col_209',['col',['../lcd_8c.html#a1f5766979d509ddbf5fd28eefa29f56f',1,'lcd.c']]]
];
