/*
 * menu_normal.h
 *
 *  Created on: 08/10/2019
 *      Author: A38866
 */

#ifndef MENU_NORMAL_H_
#define MENU_NORMAL_H_

#include "menu.h"
#include "menu_maintenance.h"

void * normal_execution();

#endif /* MENU_NORMAL_H_ */
