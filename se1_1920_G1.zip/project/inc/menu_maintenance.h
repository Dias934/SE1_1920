/*
 * menu_maintenance.h
 *
 *  Created on: 08/10/2019
 *      Author: A38866
 */

#ifndef MENU_MAINTENANCE_H_
#define MENU_MAINTENANCE_H_

#include "menu.h"
#include "menu_normal.h"

#define TEN_SECONDS 10000

void * maintenance_execution();

#endif /* MENU_MAINTENANCE_H_ */
